//+----------------------------------------------------------------------------------------------+
//| Copyright © <2018>  <LizardIndicators.com - powered by AlderLab UG>
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Core;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators.LizardIndicators;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.LizardIndicators
{
	/// <summary>
	/// The Better Volume indicator is a tool for volume spread analysis. It can be used to identify climax bar, churn bars, climax churn bars and low volume bars. Typically a climax or expansion bar 
	/// is a high volume wide range bar, while a churn bar is a high volume narrow range bar. Climax churn bars are bars that comply with both the conditions for a climax and a churn bar.
	/// This version of the Better Volume indicator can be applied to absolute volume or to relative volume. The Better Volume approach should only be used with time based bars.
	/// </summary>
	[Gui.CategoryOrder("Volume Input", 0)]
	[Gui.CategoryOrder("Volume Analysis", 10)]
	[Gui.CategoryOrder("Display Options", 20)]
	[Gui.CategoryOrder("Data Series", 30)]
	[Gui.CategoryOrder("Set up", 40)]
	[Gui.CategoryOrder("Visual", 50)]
	[Gui.CategoryOrder("Plots", 60)]
	[Gui.CategoryOrder("Zeroline", 65)]
	[Gui.CategoryOrder("Paint Bars", 70)]
	[Gui.CategoryOrder("Sound Alerts", 80)]
	[Gui.CategoryOrder("Version", 90)]
	[TypeConverter("NinjaTrader.NinjaScript.Indicators.amaBetterVolumeTypeConverter")]
	public class amaBetterVolume : Indicator
	{
        private int 							longPeriod	 				= 20;
		private int  							shortPeriod					= 10;
		private int  							lPeriod						= 0;
		private int 							sPeriod						= 0;
		private int								days						= 40;
		private int 							weeks						= 8;
		private int								displacement				= 0;
		private int 							width						= 3;
		private int 							rearmTime					= 30;
		private double 							volume						= 0.0;
		private double 							expandedRange				= 0.0;
		private double 							pressure					= 0.0;
		private double 							density						= 0.0;
		private double 							lmaxPValue					= 0.0;
		private double 							lmaxDValue					= 0.0;
		private double 							lsmaValue					= 0.0;
		private double 							smaxPValue					= 0.0;
		private double 							smaxDValue					= 0.0;
		private double 							ssmaValue					= 0.0;
		private double 							volMin						= 0.0;
		private bool 							includeWeakSignals			= false;
		private bool 							showVolume					= true;
		private bool 							showPaintBars				= true;
		private bool 							candles						= true;
		private bool 							soundAlerts 				= false;
		private bool							breakAtEOD					= true;
		private bool							calculateFromPriceData		= true;
		private bool							errorMessage				= false;
		private bool							basicError					= false;
		private bool							sundaySessionError			= false;
		private DateTime						sessionDateTmp				= Globals.MinDate;
		private DateTime						cacheSessionEndTmp			= Globals.MinDate;
		private DateTime						lastBarTimeStamp			= Globals.MinDate;
		private DateTime						currentDate					= Globals.MinDate;
		private amaBetterVolumeType				volumeType					= amaBetterVolumeType.Absolute_Volume;
		private amaRVCalcMode					calcMode					= amaRVCalcMode.All_Days;
		private SessionIterator					sessionIterator				= null;
		private System.Windows.Media.Brush 		climaxChurnBrush			= Brushes.DeepPink;
		private System.Windows.Media.Brush 		climaxBrush					= Brushes.Blue;
		private System.Windows.Media.Brush 		churnBrush					= Brushes.Yellow;
		private System.Windows.Media.Brush 		weakClimaxChurnBrush		= Brushes.Magenta;
		private System.Windows.Media.Brush 		weakClimaxBrush				= Brushes.DeepSkyBlue;
		private System.Windows.Media.Brush 		weakChurnBrush				= Brushes.DarkOrange;
		private System.Windows.Media.Brush 		lowVolumeBrush				= Brushes.White;
		private System.Windows.Media.Brush 		upBrush						= Brushes.Green;
		private System.Windows.Media.Brush 		downBrush					= Brushes.Firebrick;
		private System.Windows.Media.Brush 		neutralBrush				= Brushes.SlateGray;
		private System.Windows.Media.Brush 		climaxChurnBar				= Brushes.DeepPink;
		private System.Windows.Media.Brush 		climaxChurnBarUp			= Brushes.DeepPink;
		private System.Windows.Media.Brush 		climaxChurnOutline			= Brushes.White;
		private System.Windows.Media.Brush 		climaxBar					= Brushes.Blue;
		private System.Windows.Media.Brush 		climaxBarUp					= Brushes.Blue;
		private System.Windows.Media.Brush 		climaxOutline				= Brushes.Black;
		private System.Windows.Media.Brush 		churnBar					= Brushes.Yellow;
		private System.Windows.Media.Brush 		churnBarUp					= Brushes.Yellow;
		private System.Windows.Media.Brush 		churnOutline				= Brushes.Black;
		private System.Windows.Media.Brush 		weakClimaxChurnBar			= Brushes.Magenta;
		private System.Windows.Media.Brush 		weakClimaxChurnBarUp		= Brushes.Magenta;
		private System.Windows.Media.Brush 		weakClimaxChurnOutline		= Brushes.Black;
		private System.Windows.Media.Brush 		weakClimaxBar				= Brushes.DeepSkyBlue;
		private System.Windows.Media.Brush 		weakClimaxBarUp				= Brushes.DeepSkyBlue;
		private System.Windows.Media.Brush 		weakClimaxOutline			= Brushes.Black;
		private System.Windows.Media.Brush 		weakChurnBar				= Brushes.DarkOrange;
		private System.Windows.Media.Brush 		weakChurnBarUp				= Brushes.DarkOrange;
		private System.Windows.Media.Brush 		weakChurnOutline			= Brushes.Black;
		private System.Windows.Media.Brush 		lowVolumeBar				= Brushes.White;
		private System.Windows.Media.Brush 		lowVolumeBarUp				= Brushes.White;
		private System.Windows.Media.Brush 		lowVolumeOutline			= Brushes.Black;
		private System.Windows.Media.Brush 		upBar						= Brushes.Green;
		private System.Windows.Media.Brush 		upOutline					= Brushes.Black;
		private System.Windows.Media.Brush 		downBar						= Brushes.Firebrick;
		private System.Windows.Media.Brush 		downOutline					= Brushes.Black;
		private System.Windows.Media.Brush 		neutralOutline				= Brushes.Black;
		private System.Windows.Media.Brush 		zerolineBrush				= Brushes.DarkGray;
		private System.Windows.Media.Brush		alertBackBrush				= Brushes.Black;
		private System.Windows.Media.Brush		errorBrush					= Brushes.Black;
		private int								upcloseOpacity				= 65;
		private int								barWidth					= 5;
		private int								zerolineWidth				= 1;
		private SimpleFont						errorFont;
		private string							errorText1					= "The amaBetterVolume indicator can only be used with price data.";
		private string							errorText2					= "The amaBetterVolume indicator can only be used with relative volume when applied to minute, daily or weekly bars.";
		private string							errorText3					= "Please set the amaBetterVolume indicator to calculation mode 'All_Days' when used with relative volume and weekly data.";
		private string							errorText4					= "The amaBetterVolume indicator cannot be used with relative volume when the 'Break at EOD' data series property is unselected.";
		private string							errorText5					= "The amaBetterVolume cannot be used with a displacement.";
		private string							errorText6					= "When set to 'All_Days', the amaBetterVolume indicator can only be used with session templates adapted to the trading hours of the instrument.";
		private string							errorText7					= "amaBetterVolume: Insufficient historical data. Please increase chart lookback period to show relative volume.";
		private int								rearmSeconds				= 30;
		private string 							climaxChurnAlert			= "climaxchurnbar.wav";
		private string 							climaxAlert					= "climaxbar.wav";
		private string 							churnAlert					= "churnbar.wav";
		private string 							weakClimaxChurnAlert		= "weakclimaxchurnbar.wav";
		private string 							weakClimaxAlert				= "weakclimaxbar.wav";
		private string 							weakChurnAlert				= "weakchurnbar.wav";
		private string 							lowVolumeAlert				= "lowvolumebar.wav";
		private string							pathClimaxChurnAlert		= "";
		private string							pathClimaxAlert				= "";
		private string							pathChurnAlert				= "";
		private string							pathWeakClimaxChurnAlert	= "";
		private string							pathWeakClimaxAlert			= "";
		private string							pathWeakChurnAlert			= "";
		private string							pathLowVolumeAlert			= "";
		private string							versionString				= "v 1.3  - January 11, 2019";
		private Series<double> 					volPressure;
		private Series<double> 					volDensity;
		private Series<double> 					barType;
		
		public Series<int> 						Signal;
		
		private amaRelativeVolume				relativeVolume;
		private MAX 							lmaxPressure;
		private MAX 							lmaxDensity;
		private MAX 							smaxPressure;
		private MAX 							smaxDensity;
		private SMA 							lsmaVolume;
		private SMA 							ssmaVolume;
		private MIN 							minVolume;
	
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "\r\n The Better Volume indicator is a tool for volume spread analysis. It can be used to identify climax bar, churn bars, climax churn bars and low volume bars."
												+ " Typically a climax or expansion bar is a high volume wide range bar, while a churn bar is a high volume narrow range bar. Climax churn bars are bars that comply"
												+ " with both the conditions for a climax and a churn bar. This version of the Better Volume indicator can be applied to absolute volume or to relative volume."
												+ " The Better Volume approach should only be used with time based bars.";
				Name						= "amaBetterVolume";
				IsSuspendedWhileInactive	= false;
				ArePlotsConfigurable		= false;
				AreLinesConfigurable		= false;
				DrawOnPricePanel			= false;
				AddPlot(new Stroke(Brushes.Gray, 4), PlotStyle.Bar, "Base Volume");
				AddLine(new Stroke(Brushes.Gray, 1), 0, "Zeroline");
			}
			else if (State == State.Configure)
			{
				displacement = Displacement;
				BarsRequiredToPlot = longPeriod;
				if(Calculate == Calculate.OnPriceChange)
					Calculate = Calculate.OnEachTick;
				Plots[0].Width = barWidth;
				if(showVolume)
				{	
					Lines[0].Width = zerolineWidth;
					Lines[0].Brush = zerolineBrush;
				}
				else
					Lines[0].Brush = Brushes.Transparent;
				climaxChurnBarUp = climaxChurnBar.Clone();
				climaxChurnBarUp.Opacity = (float) upcloseOpacity/100.0;
				climaxChurnBarUp.Freeze();
				climaxBarUp = climaxBar.Clone();
				climaxBarUp.Opacity = (float) upcloseOpacity/100.0;
				climaxBarUp.Freeze();
				churnBarUp = churnBar.Clone();
				churnBarUp.Opacity = (float) upcloseOpacity/100.0;
				churnBarUp.Freeze();
				weakClimaxChurnBarUp = weakClimaxChurnBar.Clone();
				weakClimaxChurnBarUp.Opacity = (float) upcloseOpacity/100.0;
				weakClimaxChurnBarUp.Freeze();
				weakClimaxBarUp = weakClimaxBar.Clone();
				weakClimaxBarUp.Opacity = (float) upcloseOpacity/100.0;
				weakClimaxBarUp.Freeze();
				weakChurnBarUp = weakChurnBar.Clone();
				weakChurnBarUp.Opacity = (float) upcloseOpacity/100.0;
				weakChurnBarUp.Freeze();
				lowVolumeBarUp = lowVolumeBar.Clone();
				lowVolumeBarUp.Opacity = (float) upcloseOpacity/100.0;
				lowVolumeBarUp.Freeze();
			}
			else if (State == State.DataLoaded)
			{	
				volPressure = new Series<double>(this, longPeriod < 256 ? MaximumBarsLookBack.TwoHundredFiftySix : MaximumBarsLookBack.Infinite);
				volDensity	= new Series<double>(this, longPeriod < 256 ? MaximumBarsLookBack.TwoHundredFiftySix : MaximumBarsLookBack.Infinite);
				barType = new Series<double>(this, MaximumBarsLookBack.Infinite);
				
				Signal  = new Series<int>(this);
				
				relativeVolume = amaRelativeVolume(calcMode, days, weeks, 120, 80);
				lPeriod = longPeriod - 1;
				lmaxPressure = MAX(volPressure, lPeriod);
				lmaxDensity = MAX(volDensity, lPeriod);
				lsmaVolume = SMA(BaseVolume, lPeriod);
				if(includeWeakSignals)
				{	
					sPeriod = shortPeriod - 1;
					smaxPressure = MAX(volPressure, sPeriod);
					smaxDensity = MAX(volDensity, sPeriod);
					ssmaVolume = SMA(BaseVolume, sPeriod);
					minVolume = MIN(BaseVolume, sPeriod);
				}	
				else
					minVolume = MIN(BaseVolume, lPeriod);
				if(Input is PriceSeries)
					calculateFromPriceData = true;
				else
					calculateFromPriceData = false;
		    	sessionIterator = new SessionIterator(Bars);
			}
			else if (State == State.Historical)
			{	
				pathClimaxChurnAlert = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, climaxChurnAlert);
				pathClimaxAlert = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, climaxAlert);
				pathChurnAlert = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, churnAlert);
				pathWeakClimaxChurnAlert = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, weakClimaxChurnAlert);
				pathWeakClimaxAlert = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, weakClimaxAlert);
				pathWeakChurnAlert = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, weakChurnAlert);
				pathLowVolumeAlert = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, lowVolumeAlert);
				if(ChartBars != null)
				{	
					breakAtEOD = ChartBars.Bars.IsResetOnNewTradingDay;
					errorBrush = ChartControl.Properties.AxisPen.Brush;
					errorBrush.Freeze();
					errorFont = new SimpleFont("Arial", 24);
					if(!calculateFromPriceData)
					{
						Draw.TextFixed(this, "error text 1", errorText1, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
						errorMessage = true;
						basicError = true;
					}	
					else if(volumeType == amaBetterVolumeType.Relative_Volume && Bars.BarsPeriod.BarsPeriodType != BarsPeriodType.Minute && Bars.BarsPeriod.BarsPeriodType != BarsPeriodType.Day 
						&& Bars.BarsPeriod.BarsPeriodType != BarsPeriodType.Week)
					{
						Draw.TextFixed(this, "error text 2", errorText2, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
						errorMessage = true;
						basicError = true;
					}
					else if (Bars.BarsPeriod.BarsPeriodType == BarsPeriodType.Week && calcMode == amaRVCalcMode.Day_Of_Week)
					{
						Draw.TextFixed(this, "error text 3", errorText3, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
						errorMessage = true;
						basicError = true;
					}
					else if(volumeType == amaBetterVolumeType.Relative_Volume && !breakAtEOD)
					{
						Draw.TextFixed(this, "error text 4", errorText4, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
						errorMessage = true;
						basicError = true;
					}
					else if(displacement != 0)
					{
						Draw.TextFixed(this, "error text 5", errorText5, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
						errorMessage = true;
						basicError = true;
					}
				}	

			}	
		}
		
		protected override void OnBarUpdate()
		{
			if(IsFirstTickOfBar)
			{	
				if(errorMessage)
				{	
					if(basicError)
						return;
					else if(sundaySessionError)
					{	
						Draw.TextFixed(this, "error text 6", errorText6, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);
						return;
					}	
				}
				
				if(calcMode == amaRVCalcMode.All_Days)
				{	
					lastBarTimeStamp = GetLastBarSessionDate(Time[0]);
					if(lastBarTimeStamp > currentDate)
					{	
						if(lastBarTimeStamp.DayOfWeek == DayOfWeek.Sunday)
						{
							sundaySessionError = true;
							errorMessage = true;
							return;
						}
						currentDate = lastBarTimeStamp;
					}
				}
			}
			else if(errorMessage)
				return;
			
			if(volumeType == amaBetterVolumeType.Absolute_Volume)
				volume = Volume[0];
			else if (relativeVolume.IsValidDataPoint(0))
				volume = relativeVolume[0];	
			else
			{	
				BaseVolume.Reset();
				volPressure.Reset();
				volDensity.Reset();
				barType.Reset();
				return;
			}	
			BaseVolume[0] = volume;
			if(BarsPeriod.BarsPeriodType != BarsPeriodType.Range)
				expandedRange = 1 + (High[0] - Low[0])/TickSize;
			else
				expandedRange = 1 + Math.Abs((Open[0] - Close[0]))/TickSize;
			
			pressure = volume * expandedRange;
			density = volume / expandedRange;
			volPressure[0] = pressure;
			volDensity[0] = density;
			
			if(CurrentBar < longPeriod)
			{
				barType.Reset();
				return;
			}
			
			if(IsFirstTickOfBar)
			{
				lmaxPValue = lmaxPressure[1];
				lmaxDValue = lmaxDensity[1];
				lsmaValue = lsmaVolume[1];
				if(includeWeakSignals)
				{	
					smaxPValue = smaxPressure[1];
					smaxDValue = smaxDensity[1];
					ssmaValue = ssmaVolume[1];
				}	
				
				if(Calculate == Calculate.OnBarClose)
					volMin = minVolume[1];
				else if (Volume[1] < minVolume[2]) // case Calculate == Calculate.OnEachTick
				{	
					Signal[0] = 0;
					if(showVolume)
						PlotBrushes[0][1] = lowVolumeBrush;
					else
						PlotBrushes[0][1] = Brushes.Transparent;
					if (showPaintBars)
					{
						//CandleOutlineBrushes[1] = lowVolumeOutline;
						if(candles && Open[1] < Close[1])
							BarBrushes[1] = lowVolumeBarUp;
						else
							BarBrushes[1] = lowVolumeBar;
					}
					if(soundAlerts && State == State.Realtime && IsConnected())
					{
						try
						{	
							Alert("Low_Volume", Priority.Medium, "Low Volume", pathLowVolumeAlert, rearmTime, alertBackBrush, lowVolumeBrush);
						}
						catch {}
					}
				}
			}
			
			if(pressure >= lmaxPValue && density >= lmaxDValue)			
			{
				Signal[0] = 6;
				NinjaTrader.Gui.Tools.SimpleFont arrowFont = new NinjaTrader.Gui.Tools.SimpleFont("Wingdings", 10){ Bold = true };
				DrawOnPricePanel = true;
				Draw.Text(this, "cmxchrn"+CurrentBar, false, "u", 0, High[0]+10*TickSize,0, climaxChurnBrush, arrowFont, System.Windows.TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
				DrawOnPricePanel = false;
			
				if(showVolume)
					PlotBrushes[0][0] = climaxChurnBrush;
				else
					PlotBrushes[0][0] = Brushes.Transparent;
				
				if(Close[0] > Open[0])
					CandleOutlineBrushes[0] = Brushes.Lime;
				else 
					CandleOutlineBrushes[0] = Brushes.Red;
				
				barType[0] = 0;
				if (showPaintBars)
				{
					if(Close[0] > Open[0])
						BarBrushes[0] = climaxChurnBarUp;
					else 
						BarBrushes[0] = climaxChurnBar;				
				
					
				}
				if (soundAlerts && State == State.Realtime && IsConnected())
				{
					try
					{	
						Alert("Climax_Churn", Priority.Medium, "Climax Churn", pathClimaxChurnAlert, rearmTime, alertBackBrush, climaxChurnBrush);
					}
					catch {}
				}
			}	
			else if (pressure >= lmaxPValue && volume > lsmaValue)
			{	
				Signal[0] = 5;
				
				if(showVolume)
					PlotBrushes[0][0] = climaxBrush;
				else
					PlotBrushes[0][0] = Brushes.Transparent;
				barType[0] = 1;
				if(Close[0] > Open[0])
					CandleOutlineBrushes[0] = Brushes.Lime;
				else 
					CandleOutlineBrushes[0] = Brushes.Red;
				if (showPaintBars)
				{
					if(Close[0] > Open[0])
						BarBrushes[0] = climaxBarUp;
					else 
						BarBrushes[0] = climaxBar;
					//CandleOutlineBrushes[0] = climaxOutline;
				}
				if (soundAlerts && State == State.Realtime && IsConnected())
				{
					try
					{	
						Alert("Climax", Priority.Medium, "Climax", pathClimaxAlert, rearmTime, alertBackBrush, climaxBrush);
					}
					catch {}
				}
			}
			else if (density >= lmaxDValue && volume > lsmaValue )
			{
				Signal[0] = 4;
				
				if(pressure >= smaxPValue)
				{
					NinjaTrader.Gui.Tools.SimpleFont arrowFont = new NinjaTrader.Gui.Tools.SimpleFont("Wingdings", 9){ Bold = true };
					DrawOnPricePanel = true;
					Draw.Text(this, "churn"+CurrentBar, false, "u", 0, High[0]+10*TickSize,0, churnBrush, arrowFont, System.Windows.TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
					DrawOnPricePanel = false;
				}
				
				if(showVolume)
					PlotBrushes[0][0] = churnBrush;
				else
					PlotBrushes[0][0] = Brushes.Transparent;
				barType[0] = 2;
			
				
				if (showPaintBars)
				{
					if(Close[0] > Open[0])
						BarBrushes[0] = churnBarUp;
					else 
						BarBrushes[0] = churnBar;
					//CandleOutlineBrushes[0] = churnOutline;
				}
				if (soundAlerts && State == State.Realtime && IsConnected())
				{
					try
					{	
						Alert("Churn", Priority.Medium, "Churn", pathChurnAlert, rearmTime, alertBackBrush, churnBrush);
					}
					catch {}
				}
			}
			else if(includeWeakSignals && pressure >= smaxPValue && density >= smaxDValue)
			{
				Signal[0] = 3;
				
				if(showVolume)
					PlotBrushes[0][0] = weakClimaxChurnBrush;
				else
					PlotBrushes[0][0] = Brushes.Transparent;
				barType[0] = 3;
				if (showPaintBars)
				{
					if(Close[0] > Open[0])
						BarBrushes[0] = weakClimaxChurnBarUp;
					else 
						BarBrushes[0] = weakClimaxChurnBar;
					//CandleOutlineBrushes[0] = weakClimaxChurnOutline;
				}
				if (soundAlerts && State == State.Realtime && IsConnected())
				{
					try
					{	
						Alert("Weak_Climax_Churn", Priority.Medium, "Weak Climax Churn", pathWeakClimaxChurnAlert, rearmTime, alertBackBrush, weakClimaxChurnBrush);
					}
					catch {}
				}
			}	
			else if (includeWeakSignals && pressure >= smaxPValue && volume > ssmaValue)
			{
				Signal[0] = 2;
				
				if(showVolume)
					PlotBrushes[0][0] = weakClimaxBrush;
				else
					PlotBrushes[0][0] = Brushes.Transparent;
				barType[0] = 4;
				if (showPaintBars)
				{
					if(Close[0] > Open[0])
						BarBrushes[0] = weakClimaxBarUp;
					else 
						BarBrushes[0] = weakClimaxBar;
					//CandleOutlineBrushes[0] = weakClimaxOutline;
				}
				if (soundAlerts && State == State.Realtime && IsConnected())
				{
					try
					{	
						Alert("Weak_Climax", Priority.Medium, "Weak Climax", pathWeakClimaxAlert, rearmTime, alertBackBrush, weakClimaxBrush);
					}
					catch {}
				}
			}
			else if (includeWeakSignals && density >= smaxDValue && volume > ssmaValue)
			{
				Signal[0] = 1;
				
				barType[0] = 5;
				if(showVolume)
					PlotBrushes[0][0] = weakChurnBrush;
				else
					PlotBrushes[0][0] = Brushes.Transparent;
				if (showPaintBars)
				{
					if(Close[0] > Open[0])
						BarBrushes[0] = weakChurnBarUp;
					else 
						BarBrushes[0] = weakChurnBar;
					//CandleOutlineBrushes[0] = weakChurnOutline;
				}
				if (soundAlerts && State == State.Realtime && IsConnected())
				{
					try
					{	
						Alert("Weak_Churn", Priority.Medium, "Weak Churn", pathWeakChurnAlert, rearmTime, alertBackBrush, weakChurnBrush);
					}
					catch {}
				}
			}			
			else if (Calculate == Calculate.OnBarClose && volume <= volMin) 
			{
				Signal[0] = 0;
				
				barType[0] = 6;
				if(showVolume)
					PlotBrushes[0][0] = lowVolumeBrush;
				else
					PlotBrushes[0][0] = Brushes.Transparent;
				if (showPaintBars)
				{
					if(Close[0] > Open[0])
						BarBrushes[0] = lowVolumeBarUp;
					else 
						BarBrushes[0] = lowVolumeBar;
					//CandleOutlineBrushes[0] = lowVolumeOutline;
				}	
				if(soundAlerts && State == State.Realtime && IsConnected() && IsConnected())
				{
					try
					{	
						Alert("Low_Volume", Priority.Medium, "Low Volume", pathLowVolumeAlert, rearmTime, alertBackBrush, lowVolumeBrush);
					}
					catch {}
				}
			}
			else if (Calculate == Calculate.OnBarClose)
			{
				if(Close[0] > Open[0])
				{
					barType[0] = 7;
					if(showVolume)
						PlotBrushes[0][0] = upBrush;
					else
						PlotBrushes[0][0] = Brushes.Transparent;
					if (showPaintBars)
					{
						BarBrushes[0] = upBar;
						//CandleOutlineBrushes[0] = upOutline;
					}	
				}	
				else if (Close[0] < Open[0])
				{
					barType[0] = 8;
					if(showVolume)
						PlotBrushes[0][0] = downBrush;
					else
						PlotBrushes[0][0] = Brushes.Transparent;
					if (showPaintBars)
					{
						BarBrushes[0] = downBar;
						//CandleOutlineBrushes[0] = downOutline;
					}	
				}	
				else
				{
					barType[0] = 9;
					if(showVolume)
						PlotBrushes[0][0] = neutralBrush;
					else
						PlotBrushes[0][0] = Brushes.Transparent;
					if (showPaintBars)
					{
						BarBrushes[0] = downBar;
						//CandleOutlineBrushes[0] = neutralOutline;
					}	
				}
			}
			else // case Calculate == Calculate.OnEachTick
			{
				if(Close[0] > Open[0])
				{
					barType[0] = 7;
					if(showVolume)
						PlotBrushes[0][0] = upBrush;
					else
						PlotBrushes[0][0] = Brushes.Transparent;
					if (showPaintBars)
					{
						BarBrushes[0] = upBar;
						//CandleOutlineBrushes[0] = upOutline;
					}	
				}	
				else if (Close[0] < Open[0])
				{
					barType[0] = 8;
					if(showVolume)
						PlotBrushes[0][0] = downBrush;
					else
						PlotBrushes[0][0] = Brushes.Transparent;
					if (showPaintBars)
					{
						BarBrushes[0] = downBar;
						//CandleOutlineBrushes[0] = downOutline;
					}	
				}	
				else
				{
					barType[0] = 9;
					if(showVolume)
						PlotBrushes[0][0] = neutralBrush;
					else
						PlotBrushes[0][0] = Brushes.Transparent;
					if (showPaintBars)
					{
						BarBrushes[0] = downBar;
						//CandleOutlineBrushes[0] = neutralOutline;
					}	
				}
				if(volume < volMin)
					barType[0] = 6;
			}
		}

		#region Properties
		
        [Browsable(false)]	
        [XmlIgnore()]		
        public Series<double> BaseVolume
        {
            get { return Values[0]; }
        }
		
        [Browsable(false)]	
        [XmlIgnore()]		
        public Series<double> BarType
        {
            get { return barType; }
        }
		
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Volume base", Description = "Select between absolute and relative volume", GroupName = "Volume Input", Order = 0)]
 		[RefreshProperties(RefreshProperties.All)] 
		public amaBetterVolumeType VolumeType
		{	
            get { return volumeType; }
            set { volumeType = value; }
		}
		
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Calculation mode", Description = "Select between comparing current volume to average volume of all days or same day of week only", GroupName = "Volume Input", Order = 1)]
 		[RefreshProperties(RefreshProperties.All)] 
		public amaRVCalcMode CalcMode
		{	
            get { return calcMode; }
            set { calcMode = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Reference period in days",  Description = "Sets the reference period which is used for calculating relative volume", GroupName = "Volume Input", Order = 2)]
		public int Days
		{
			get { return days; }
			set { days = Math.Max(1, value); }
		}

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Reference period in weeks", Description = "Sets the reference period which is used for calculating relative volume", GroupName = "Volume Input", Order = 3)]
		public int Weeks
		{
			get { return weeks; }
			set { weeks = Math.Max(1, value); }
		}
			
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Include weak signals", Description = "Display weak climax and churn bars based on the short period", GroupName = "Volume Analysis", Order = 0)]
 		[RefreshProperties(RefreshProperties.All)] 
		public bool IncludeWeakSignals
		{	
            get { return includeWeakSignals; }
            set { includeWeakSignals = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Long period", Description = "Lookback period used for identifying strong climax and churn bars", GroupName = "Volume Analysis", Order = 1)]
		public int LongPeriod
		{	
            get { return longPeriod; }
            set { longPeriod = value; }
		}

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Short period", Description = "Lookback period used for identifying weak climax and churn bars", GroupName = "Volume Analysis", Order = 2)]
		public int ShortPeriod
		{	
            get { return shortPeriod; }
            set { shortPeriod = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show volume", GroupName = "Display Options", Order = 0)]
  		[RefreshProperties(RefreshProperties.All)] 
       	public bool ShowVolume
        {
            get { return showVolume; }
            set { showVolume = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show paint bars", GroupName = "Display Options", Order = 1)]
  		[RefreshProperties(RefreshProperties.All)] 
       	public bool ShowPaintBars
        {
            get { return showPaintBars; }
            set { showPaintBars = value; }
        }
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Climax churn bar", Description = "Sets the color for a climax churn bar", GroupName = "Plots", Order = 0)]
		public System.Windows.Media.Brush ClimaxChurnBrush
		{ 
			get {return climaxChurnBrush;}
			set {climaxChurnBrush = value;}
		}

		[Browsable(false)]
		public string ClimaxChurnBrushSerializable
		{
			get { return Serialize.BrushToString(climaxChurnBrush); }
			set { climaxChurnBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Climax bar", Description = "Sets the color for a climax bar", GroupName = "Plots", Order = 1)]
		public System.Windows.Media.Brush ClimaxBrush
		{ 
			get {return climaxBrush;}
			set {climaxBrush = value;}
		}

		[Browsable(false)]
		public string ClimaxBrushSerializable
		{
			get { return Serialize.BrushToString(climaxBrush); }
			set { climaxBrush = Serialize.StringToBrush(value); }
		}		
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Churn bar", Description = "Sets the color for a churn bar", GroupName = "Plots", Order = 2)]
		public System.Windows.Media.Brush ChurnBrush
		{ 
			get {return churnBrush;}
			set {churnBrush = value;}
		}

		[Browsable(false)]
		public string ChurnBrushSerializable
		{
			get { return Serialize.BrushToString(churnBrush); }
			set { churnBrush = Serialize.StringToBrush(value); }
		}		
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Weak climax churn bar", Description = "Sets the color for a weak climax churn bar", GroupName = "Plots", Order = 3)]
		public System.Windows.Media.Brush WeakClimaxChurnBrush
		{ 
			get {return weakClimaxChurnBrush;}
			set {weakClimaxChurnBrush = value;}
		}

		[Browsable(false)]
		public string WeakClimaxChurnBrushSerializable
		{
			get { return Serialize.BrushToString(weakClimaxChurnBrush); }
			set { weakClimaxChurnBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Weak climax bar", Description = "Sets the color for a weak climax bar", GroupName = "Plots", Order = 4)]
		public System.Windows.Media.Brush WeakClimaxBrush
		{ 
			get {return weakClimaxBrush;}
			set {weakClimaxBrush = value;}
		}

		[Browsable(false)]
		public string WeakClimaxBrushSerializable
		{
			get { return Serialize.BrushToString(weakClimaxBrush); }
			set { weakClimaxBrush = Serialize.StringToBrush(value); }
		}		
				
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Weak churn bar", Description = "Sets the color for a weak churn bar", GroupName = "Plots", Order = 5)]
		public System.Windows.Media.Brush WeakChurnBrush
		{ 
			get {return weakChurnBrush;}
			set {weakChurnBrush = value;}
		}

		[Browsable(false)]
		public string WeakChurnBrushSerializable
		{
			get { return Serialize.BrushToString(weakChurnBrush); }
			set { weakChurnBrush = Serialize.StringToBrush(value); }
		}		
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Low volume bar", Description = "Sets the color for a low volume bar", GroupName = "Plots", Order = 6)]
		public System.Windows.Media.Brush LowVolumeBrush
		{ 
			get {return lowVolumeBrush;}
			set {lowVolumeBrush = value;}
		}

		[Browsable(false)]
		public string LowVolumeBrushSerializable
		{
			get { return Serialize.BrushToString(lowVolumeBrush); }
			set { lowVolumeBrush = Serialize.StringToBrush(value); }
		}							

		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Upclose bar", Description = "Set the color for an upclose bar", GroupName = "Plots", Order = 7)]
		public System.Windows.Media.Brush UpBrush
		{ 
			get {return upBrush;}
			set {upBrush = value;}
		}

		[Browsable(false)]
		public string UpBrushSerializable
		{
			get { return Serialize.BrushToString(upBrush); }
			set { upBrush = Serialize.StringToBrush(value); }
		}					
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Downclose bar", Description = "Sets the color for a downclose bar", GroupName = "Plots", Order = 8)]
		public System.Windows.Media.Brush DownBrush
		{ 
			get {return downBrush;}
			set {downBrush = value;}
		}

		[Browsable(false)]
		public string DownBrushSerializable
		{
			get { return Serialize.BrushToString(downBrush); }
			set { downBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Doji bar", Description = "Sets the color for a doji bar", GroupName = "Plots", Order = 9)]
		public System.Windows.Media.Brush NeutralBrush
		{ 
			get {return neutralBrush;}
			set {neutralBrush = value;}
		}

		[Browsable(false)]
		public string NeutralBrushSerializable
		{
			get { return Serialize.BrushToString(neutralBrush); }
			set { neutralBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bar width", Description = "Sets the width for the bars of the volume histogram", GroupName = "Plots", Order = 10)]
		public int BarWidth
		{	
            get { return barWidth; }
            set { barWidth = value; }
		}

		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Line color", Description = "Sets the color for the zeroline", GroupName = "Zeroline", Order = 0)]
		public System.Windows.Media.Brush ZerolineBrush
		{ 
			get {return zerolineBrush;}
			set {zerolineBrush = value;}
		}

		[Browsable(false)]
		public string ZerolineBrushSerializable
		{
			get { return Serialize.BrushToString(zerolineBrush); }
			set { zerolineBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Line width", Description = "Sets the width for the zeroline", GroupName = "Zeroline", Order = 1)]
		public int ZerolineWidth
		{	
            get { return zerolineWidth; }
            set { zerolineWidth = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Climax churn bar", Description = "Sets the color for a climax churn bar", GroupName = "Paint Bars", Order = 0)]
		public System.Windows.Media.Brush ClimaxChurnBar
		{ 
			get {return climaxChurnBar;}
			set {climaxChurnBar = value;}
		}

		[Browsable(false)]
		public string ClimaxChurnBarSerializable
		{
			get { return Serialize.BrushToString(climaxChurnBar); }
			set { climaxChurnBar = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Climax churn outline", Description = "Sets the color for the candle outline of a climax churn bar", GroupName = "Paint Bars", Order = 1)]
		public System.Windows.Media.Brush ClimaxChurnOutline
		{ 
			get {return climaxChurnOutline;}
			set {climaxChurnOutline = value;}
		}

		[Browsable(false)]
		public string ClimaxChurnOutlineSerializable
		{
			get { return Serialize.BrushToString(climaxChurnOutline); }
			set { climaxChurnOutline = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Climax bar", Description = "Sets the color for a climax bar", GroupName = "Paint Bars", Order = 2)]
		public System.Windows.Media.Brush ClimaxBar
		{ 
			get {return climaxBar;}
			set {climaxBar = value;}
		}

		[Browsable(false)]
		public string ClimaxBarSerializable
		{
			get { return Serialize.BrushToString(climaxBar); }
			set { climaxBar = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Climax bar outline", Description = "Sets the color for the candle outline of a climax bar", GroupName = "Paint Bars", Order = 3)]
		public System.Windows.Media.Brush ClimaxOutline
		{ 
			get {return climaxOutline;}
			set {climaxOutline = value;}
		}

		[Browsable(false)]
		public string ClimaxOutlineSerializable
		{
			get { return Serialize.BrushToString(climaxOutline); }
			set { climaxOutline = Serialize.StringToBrush(value); }
		}		
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Churn bar", Description = "Sets the color for a churn bar", GroupName = "Paint Bars", Order = 4)]
		public System.Windows.Media.Brush ChurnBar
		{ 
			get {return churnBar;}
			set {churnBar = value;}
		}

		[Browsable(false)]
		public string ChurnBarSerializable
		{
			get { return Serialize.BrushToString(churnBar); }
			set { churnBar = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Churn bar outline", Description = "Sets the color for the candle outline of a churn bar", GroupName = "Paint Bars", Order = 5)]
		public System.Windows.Media.Brush ChurnOutline
		{ 
			get {return churnOutline;}
			set {churnOutline = value;}
		}

		[Browsable(false)]
		public string ChurnOutlineSerializable
		{
			get { return Serialize.BrushToString(churnOutline); }
			set { churnOutline = Serialize.StringToBrush(value); }
		}		
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Weak climax churn bar", Description = "Sets the color for a weak climax churn bar", GroupName = "Paint Bars", Order = 6)]
		public System.Windows.Media.Brush WeakClimaxChurnBar
		{ 
			get {return weakClimaxChurnBar;}
			set {weakClimaxChurnBar = value;}
		}

		[Browsable(false)]
		public string WeakClimaxChurnBarSerializable
		{
			get { return Serialize.BrushToString(weakClimaxChurnBar); }
			set { weakClimaxChurnBar = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Weak climax churn bar outline", Description = "Sets the color for the candle outline of a weak climax churn bar", GroupName = "Paint Bars", Order = 7)]
		public System.Windows.Media.Brush WeakClimaxChurnOutline
		{ 
			get {return weakClimaxChurnOutline;}
			set {weakClimaxChurnOutline = value;}
		}

		[Browsable(false)]
		public string WeakClimaxChurnOutlineSerializable
		{
			get { return Serialize.BrushToString(weakClimaxChurnOutline); }
			set { weakClimaxChurnOutline = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Weak climax bar", Description = "Sets the color for a weak climax bar", GroupName = "Paint Bars", Order = 8)]
		public System.Windows.Media.Brush WeakClimaxBar
		{ 
			get {return weakClimaxBar;}
			set {weakClimaxBar = value;}
		}

		[Browsable(false)]
		public string WeakClimaxBarSerializable
		{
			get { return Serialize.BrushToString(weakClimaxBar); }
			set { weakClimaxBar = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Weak climax bar outline", Description = "Sets the color for the candle outline of a weak climax bar", GroupName = "Paint Bars", Order = 9)]
		public System.Windows.Media.Brush WeakClimaxOutline
		{ 
			get {return weakClimaxOutline;}
			set {weakClimaxOutline = value;}
		}

		[Browsable(false)]
		public string WeakClimaxOutlineSerializable
		{
			get { return Serialize.BrushToString(weakClimaxOutline); }
			set { weakClimaxOutline = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Weak churn bar", Description = "Sets the color for a weak churn bar", GroupName = "Paint Bars", Order = 10)]
		public System.Windows.Media.Brush WeakChurnBar
		{ 
			get {return weakChurnBar;}
			set {weakChurnBar = value;}
		}

		[Browsable(false)]
		public string WeakChurnBarSerializable
		{
			get { return Serialize.BrushToString(weakChurnBar); }
			set { weakChurnBar = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Weak churn bar outline", Description = "Sets the color for the candle outline of a weak churn bar", GroupName = "Paint Bars", Order = 11)]
		public System.Windows.Media.Brush WeakChurnOutline
		{ 
			get {return weakChurnOutline;}
			set {weakChurnOutline = value;}
		}

		[Browsable(false)]
		public string WeakChurnOutlineSerializable
		{
			get { return Serialize.BrushToString(weakChurnOutline); }
			set { weakChurnOutline = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Low volume bar", Description = "Sets the color for a a low volume bar", GroupName = "Paint Bars", Order = 12)]
		public System.Windows.Media.Brush LowVolumeBar
		{ 
			get {return lowVolumeBar;}
			set {lowVolumeBar = value;}
		}

		[Browsable(false)]
		public string LowVolumeBarSerializable
		{
			get { return Serialize.BrushToString(lowVolumeBar); }
			set { lowVolumeBar = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Low volume candle outline", Description = "Sets the color for the candle outline of a low volume bar", GroupName = "Paint Bars", Order = 13)]
		public System.Windows.Media.Brush LowVolumeOutline
		{ 
			get {return lowVolumeOutline;}
			set {lowVolumeOutline = value;}
		}

		[Browsable(false)]
		public string LowVolumeOutlineSerializable
		{
			get { return Serialize.BrushToString(lowVolumeOutline); }
			set { lowVolumeOutline = Serialize.StringToBrush(value); }
		}							

		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Upclose", Description = "Sets the color for an upclose bar", GroupName = "Paint Bars", Order = 14)]
		public System.Windows.Media.Brush UpBar
		{ 
			get {return upBar;}
			set {upBar = value;}
		}

		[Browsable(false)]
		public string UpBarSerializable
		{
			get { return Serialize.BrushToString(upBar); }
			set { upBar = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Upclose candle outline", Description = "Set the color for the candle outline of an upclose bar", GroupName = "Paint Bars", Order = 15)]
		public System.Windows.Media.Brush UpOutline
		{ 
			get {return upOutline;}
			set {upOutline = value;}
		}

		[Browsable(false)]
		public string UpOutlineSerializable
		{
			get { return Serialize.BrushToString(upOutline); }
			set { upOutline = Serialize.StringToBrush(value); }
		}					
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Downclose", Description = "Sets the color for a downclose bar", GroupName = "Paint Bars", Order = 16)]
		public System.Windows.Media.Brush DownBar
		{ 
			get {return downBar;}
			set {downBar = value;}
		}

		[Browsable(false)]
		public string DownBarSerializable
		{
			get { return Serialize.BrushToString(downBar); }
			set { downBar = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Downclose candle outline", Description = "Sets the color for the candle outline of a downclose bar", GroupName = "Paint Bars", Order = 17)]
		public System.Windows.Media.Brush DownOutline
		{ 
			get {return downOutline;}
			set {downOutline = value;}
		}

		[Browsable(false)]
		public string DownOutlineSerializable
		{
			get { return Serialize.BrushToString(downOutline); }
			set { downOutline = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Doji candle outline", Description = "Sets the color for the candle outline of a doji bar", GroupName = "Paint Bars", Order = 18)]
		public System.Windows.Media.Brush NeutralOutline
		{ 
			get {return neutralOutline;}
			set {neutralOutline = value;}
		}

		[Browsable(false)]
		public string NeutralOutlineSerializable
		{
			get { return Serialize.BrushToString(neutralOutline); }
			set { neutralOutline = Serialize.StringToBrush(value); }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Upclose opacity", Description = "Sets the opacity for upclose bars", GroupName = "Paint Bars", Order = 19)]
		public int UpcloseOpacity
		{	
            get { return upcloseOpacity; }
            set { upcloseOpacity = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Sound alerts", GroupName = "Sound Alerts", Order = 0)]
    	[RefreshProperties(RefreshProperties.All)] 
      	public bool SoundAlerts
        {
            get { return soundAlerts; }
            set { soundAlerts = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Climax churn bar", Description = "Sound file for a climax churn bar", GroupName = "Sound Alerts", Order = 1)]
		public string ClimaxChurnAlert
		{	
            get { return climaxChurnAlert; }
            set { climaxChurnAlert = value; }
		}		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Climax bar", Description = "Sound file for a climax bar", GroupName = "Sound Alerts", Order = 2)]
		public string ClimaxAlert
		{	
            get { return climaxAlert; }
            set { climaxAlert = value; }
		}		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Churn bar", Description = "Sound file for a churn bar", GroupName = "Sound Alerts", Order = 3)]
		public string ChurnAlert
		{	
            get { return churnAlert; }
            set { churnAlert = value; }
		}		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Weak climax churn bar", Description = "Sound file for a weak climax churn bar", GroupName = "Sound Alerts", Order = 4)]
		public string WeakClimaxChurnAlert
		{	
            get { return weakClimaxChurnAlert; }
            set { weakClimaxChurnAlert = value; }
		}		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Weak climax bar", Description = "Sound file for a weak climax bar", GroupName = "Sound Alerts", Order = 5)]
		public string WeakClimaxAlert
		{	
            get { return weakClimaxAlert; }
            set { weakClimaxAlert = value; }
		}		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Weak churn bar", Description = "Sound file for a weak churn bar", GroupName = "Sound Alerts", Order = 6)]
		public string WeakChurnAlert
		{	
            get { return weakChurnAlert; }
            set { weakChurnAlert = value; }
		}		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Low volume bar", Description = "Sound file for a low volume bar", GroupName = "Sound Alerts", Order = 7)]
		public string LowVolumeAlert
		{	
            get { return lowVolumeAlert; }
            set { lowVolumeAlert = value; }
		}		
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Rearm time", Description = "Rearm time for alerts in seconds", GroupName = "Sound Alerts", Order = 8)]
		public int RearmSeconds
		{	
            get { return rearmSeconds; }
            set { rearmSeconds = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 0)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		#endregion
		
		#region Miscellaneous
		
		private bool IsConnected()
        {
			if ( Bars != null && Bars.Instrument.GetMarketDataConnection().PriceStatus == NinjaTrader.Cbi.ConnectionStatus.Connected
					&& sessionIterator.IsInSession(Now, true, true))
				return true;
			else
            	return false;
        }
		
		private DateTime Now
		{
          get 
			{ 
				DateTime now = (Bars.Instrument.GetMarketDataConnection().Options.Provider == NinjaTrader.Cbi.Provider.Playback ? Bars.Instrument.GetMarketDataConnection().Now : DateTime.Now); 

				if (now.Millisecond > 0)
					now = NinjaTrader.Core.Globals.MinDate.AddSeconds((long) System.Math.Floor(now.Subtract(NinjaTrader.Core.Globals.MinDate).TotalSeconds));

				return now;
			}
		}
		
		private DateTime GetLastBarSessionDate(DateTime time)
		{
			if (time > cacheSessionEndTmp) 
			{
				if (Bars.BarsType.IsIntraday)
				{	
					sessionIterator.CalculateTradingDay(time, true);
					sessionDateTmp = sessionIterator.ActualTradingDayExchange;
					cacheSessionEndTmp = sessionIterator.ActualSessionEnd;
				}	
				else
				{	
					sessionDateTmp = time.Date;
					cacheSessionEndTmp = time.Date;
				}	
			}
			return sessionDateTmp;			
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (Bars == null || ChartControl == null || !IsVisible) return;
			
			int	lastBarPainted 	 						= ChartBars.ToIndex;
			int lastBarCounted							= Inputs[0].Count - 1;
			int	lastBarOnUpdate							= lastBarCounted - (Calculate == Calculate.OnBarClose ? 1 : 0);
			int	lastBarIndex							= Math.Min(lastBarPainted, lastBarOnUpdate);
			
			if(volumeType == amaBetterVolumeType.Relative_Volume && !relativeVolume.IsValidDataPointAt(lastBarIndex))
			{
				if(!errorMessage)
				{	
					SharpDX.Direct2D1.Brush errorBrushDX = errorBrush.ToDxBrush(RenderTarget);
					TextFormat textFormat2 = new TextFormat(Globals.DirectWriteFactory, "Arial", 20.0f);		
					SharpDX.DirectWrite.TextLayout textLayout2 = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, errorText7, textFormat2, 1000, 20.0f);
					SharpDX.Vector2 lowerTextPoint = new SharpDX.Vector2(ChartPanel.W/2 - textLayout2.Metrics.Width/2, ChartPanel.Y + (ChartPanel.H/2)); 
					RenderTarget.DrawTextLayout(lowerTextPoint, textLayout2, errorBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
					errorBrushDX.Dispose();
					textFormat2.Dispose();
					textLayout2.Dispose();
				}	
				return;
			}
			base.OnRender(chartControl, chartScale);
		}
		#endregion

	}
}

namespace NinjaTrader.NinjaScript.Indicators
{		
	public class amaBetterVolumeTypeConverter : NinjaTrader.NinjaScript.IndicatorBaseConverter
	{
		public override bool GetPropertiesSupported(ITypeDescriptorContext context) { return true; }

		public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object value, Attribute[] attributes)
		{
			PropertyDescriptorCollection propertyDescriptorCollection = base.GetPropertiesSupported(context) ? base.GetProperties(context, value, attributes) : TypeDescriptor.GetProperties(value, attributes);

			amaBetterVolume				thisBetterVolumeInstance			= (amaBetterVolume) value;
			amaBetterVolumeType			volumeTypeFromInstance				= thisBetterVolumeInstance.VolumeType;
			amaRVCalcMode				calcModeFromInstance				= thisBetterVolumeInstance.CalcMode;
			bool						includeWeakSignalsFromInstance		= thisBetterVolumeInstance.IncludeWeakSignals;
			bool						showVolumeFromInstance				= thisBetterVolumeInstance.ShowVolume;
			bool						showPaintBarsFromInstance			= thisBetterVolumeInstance.ShowPaintBars;
			bool						soundAlertsFromInstance				= thisBetterVolumeInstance.SoundAlerts;
			
			PropertyDescriptorCollection adjusted = new PropertyDescriptorCollection(null);
			
			foreach (PropertyDescriptor thisDescriptor in propertyDescriptorCollection)
			{
				if (volumeTypeFromInstance == amaBetterVolumeType.Absolute_Volume && (thisDescriptor.Name == "CalcMode" || thisDescriptor.Name == "Weeks" || thisDescriptor.Name == "Days"))
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else if (calcModeFromInstance == amaRVCalcMode.All_Days && thisDescriptor.Name == "Weeks")
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else if (calcModeFromInstance == amaRVCalcMode.Day_Of_Week && thisDescriptor.Name == "Days")
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else if (!includeWeakSignalsFromInstance && (thisDescriptor.Name == "ShortPeriod" || thisDescriptor.Name == "WeakClimaxChurnBrush" || thisDescriptor.Name == "WeakClimaxBrush"   
					|| thisDescriptor.Name == "WeakChurnBrush" || thisDescriptor.Name == "WeakClimaxChurnBar" || thisDescriptor.Name == "WeakClimaxChurnOutline" || thisDescriptor.Name == "WeakClimaxBar" 
					|| thisDescriptor.Name == "WeakClimaxOutline" || thisDescriptor.Name == "WeakChurnBar" || thisDescriptor.Name == "WeakChurnOutline"))
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else if (!showVolumeFromInstance && (thisDescriptor.Name == "ClimaxChurnBrush" || thisDescriptor.Name == "ClimaxBrush" || thisDescriptor.Name == "ChurnBrush" || thisDescriptor.Name == "WeakClimaxChurnBrush"    
					|| thisDescriptor.Name == "WeakClimaxBrush"   || thisDescriptor.Name == "WeakChurnBrush" || thisDescriptor.Name == "LowVolumeBrush" || thisDescriptor.Name == "UpBrush" 
					|| thisDescriptor.Name == "DownBrush" || thisDescriptor.Name == "NeutralBrush" || thisDescriptor.Name == "BarWidth"))
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else if (!showPaintBarsFromInstance && (thisDescriptor.Name == "ClimaxChurnBar" || thisDescriptor.Name == "ClimaxChurnOutline" || thisDescriptor.Name == "ClimaxBar" || thisDescriptor.Name == "ClimaxOutline" 
					|| thisDescriptor.Name == "ChurnBar" || thisDescriptor.Name == "ChurnOutline" || thisDescriptor.Name == "WeakClimaxChurnBar" || thisDescriptor.Name == "WeakClimaxChurnOutline" 
					|| thisDescriptor.Name == "WeakClimaxBar" ||thisDescriptor.Name == "WeakClimaxOutline" || thisDescriptor.Name == "WeakChurnBar" || thisDescriptor.Name == "WeakChurnOutline" 
					|| thisDescriptor.Name == "LowVolumeBar" || thisDescriptor.Name == "LowVolumeOutline" || thisDescriptor.Name == "UpBar" || thisDescriptor.Name == "UpOutline" || thisDescriptor.Name == "DownBar" 
					|| thisDescriptor.Name == "DownOutline" || thisDescriptor.Name == "NeutralOutline" || thisDescriptor.Name == "UpcloseOpacity"))  
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else if(!soundAlertsFromInstance && (thisDescriptor.Name == "ClimaxChurnAlert" || thisDescriptor.Name == "ClimaxAlert" || thisDescriptor.Name == "ChurnAlert" || thisDescriptor.Name == "WeakClimaxChurnAlert"
					|| thisDescriptor.Name == "WeakClimaxAlert" || thisDescriptor.Name == "WeakChurnAlert" || thisDescriptor.Name == "LowVolumeAlert" || thisDescriptor.Name == "RearmSeconds"))  
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else	
					adjusted.Add(thisDescriptor);
			}
			return adjusted;
		}
	}
}

#region Public Enums
public enum amaBetterVolumeType 
{
	Absolute_Volume, 
	Relative_Volume,
}
#endregion

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LizardIndicators.amaBetterVolume[] cacheamaBetterVolume;
		public LizardIndicators.amaBetterVolume amaBetterVolume(amaBetterVolumeType volumeType, amaRVCalcMode calcMode, int days, int weeks, bool includeWeakSignals, int longPeriod, int shortPeriod)
		{
			return amaBetterVolume(Input, volumeType, calcMode, days, weeks, includeWeakSignals, longPeriod, shortPeriod);
		}

		public LizardIndicators.amaBetterVolume amaBetterVolume(ISeries<double> input, amaBetterVolumeType volumeType, amaRVCalcMode calcMode, int days, int weeks, bool includeWeakSignals, int longPeriod, int shortPeriod)
		{
			if (cacheamaBetterVolume != null)
				for (int idx = 0; idx < cacheamaBetterVolume.Length; idx++)
					if (cacheamaBetterVolume[idx] != null && cacheamaBetterVolume[idx].VolumeType == volumeType && cacheamaBetterVolume[idx].CalcMode == calcMode && cacheamaBetterVolume[idx].Days == days && cacheamaBetterVolume[idx].Weeks == weeks && cacheamaBetterVolume[idx].IncludeWeakSignals == includeWeakSignals && cacheamaBetterVolume[idx].LongPeriod == longPeriod && cacheamaBetterVolume[idx].ShortPeriod == shortPeriod && cacheamaBetterVolume[idx].EqualsInput(input))
						return cacheamaBetterVolume[idx];
			return CacheIndicator<LizardIndicators.amaBetterVolume>(new LizardIndicators.amaBetterVolume(){ VolumeType = volumeType, CalcMode = calcMode, Days = days, Weeks = weeks, IncludeWeakSignals = includeWeakSignals, LongPeriod = longPeriod, ShortPeriod = shortPeriod }, input, ref cacheamaBetterVolume);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LizardIndicators.amaBetterVolume amaBetterVolume(amaBetterVolumeType volumeType, amaRVCalcMode calcMode, int days, int weeks, bool includeWeakSignals, int longPeriod, int shortPeriod)
		{
			return indicator.amaBetterVolume(Input, volumeType, calcMode, days, weeks, includeWeakSignals, longPeriod, shortPeriod);
		}

		public Indicators.LizardIndicators.amaBetterVolume amaBetterVolume(ISeries<double> input , amaBetterVolumeType volumeType, amaRVCalcMode calcMode, int days, int weeks, bool includeWeakSignals, int longPeriod, int shortPeriod)
		{
			return indicator.amaBetterVolume(input, volumeType, calcMode, days, weeks, includeWeakSignals, longPeriod, shortPeriod);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LizardIndicators.amaBetterVolume amaBetterVolume(amaBetterVolumeType volumeType, amaRVCalcMode calcMode, int days, int weeks, bool includeWeakSignals, int longPeriod, int shortPeriod)
		{
			return indicator.amaBetterVolume(Input, volumeType, calcMode, days, weeks, includeWeakSignals, longPeriod, shortPeriod);
		}

		public Indicators.LizardIndicators.amaBetterVolume amaBetterVolume(ISeries<double> input , amaBetterVolumeType volumeType, amaRVCalcMode calcMode, int days, int weeks, bool includeWeakSignals, int longPeriod, int shortPeriod)
		{
			return indicator.amaBetterVolume(input, volumeType, calcMode, days, weeks, includeWeakSignals, longPeriod, shortPeriod);
		}
	}
}

#endregion
