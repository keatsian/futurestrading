//
// Copyright (C) 2020, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Core;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators
{
	public class DeltaNoPrint : Indicator
	{
		private double	buys;
		private double	sells;
		
		private double askBlockAccum = 0;
		private double bidBlockAccum = 0;
		
		private int pushing_ask = 0;
		private int strong_buy = 0;
		private int buy = 0;
		
		private int pushing_bid = 0;
		private int strong_sell = 0;
		private int sell = 0;
		
		private int counter = 0;
		private int activeBar = 0;
		
		private Series<double> DeltaNoPrintMomo;
		
		private int arrowSize 			= 9;
		private double arrowOffset 		= 0.5;
		private NinjaTrader.Gui.Tools.SimpleFont arrowFont;
		private NinjaTrader.Gui.Tools.SimpleFont BlockFont;
		private KeltnerChannel kcDelta;
		private double RollingMaxMomo = 0;
		
		Series<double> DeltaMomo, BarDelta, TrueMomo, UpMomo, DownMomo, DeltaClose;
		
		
		double dHTime, dLTime;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description				= "DeltaNoPrint";
				Name					= "DeltaNoPrint";
				Calculate				= Calculate.OnEachTick;
				
				DrawOnPricePanel		= false;
				IsOverlay				= false;
				DisplayInDataBox		= true;
				Block = 30;
				BSThreshold = 600;
				BSPercent = 3;

				// Plots will overlap each other no matter which one of these comes first
				// in NT8, we would add the Sells first in code and then Buys, and the "Sells" was always in front of the buys.
				/*AddPlot(new Stroke(Brushes.DarkCyan,	2), PlotStyle.Bar, "BarDelta");
				AddPlot(new Stroke(Brushes.DarkCyan,	2), PlotStyle.Dot, "AskBlockOrder");
				AddPlot(new Stroke(Brushes.DarkCyan,	2), PlotStyle.Dot, "BidBlockOrder");
				AddPlot(new Stroke(Brushes.LawnGreen, 3), PlotStyle.Hash, "UpMomo");
				AddPlot(new Stroke(Brushes.Red, 3), PlotStyle.Hash, "DownMomo");
                AddPlot(new Stroke(Brushes.DimGray, 2), PlotStyle.Square, "TrueMomo");
				AddLine(new Stroke(Brushes.DimGray, DashStyleHelper.Dash, 1), 0, "ZeroLine");
				AddPlot(new Stroke(Brushes.DarkCyan,	3), PlotStyle.Bar, "dH");
				AddPlot(new Stroke(Brushes.DarkCyan,	3), PlotStyle.Bar, "dL");
				AddPlot(new Stroke(Brushes.DimGray,	3), PlotStyle.Dot, "tH");
				AddPlot(new Stroke(Brushes.DimGray,	3), PlotStyle.Dot, "tL");*/
			}
			else if (State == State.Historical)
			{
				/*if (Calculate == Calculate.OnBarClose)
				{
					Draw.TextFixed(this, "NinjaScriptInfo", string.Format(NinjaTrader.Custom.Resource.NinjaScriptOnBarCloseError, Name), TextPosition.BottomRight);
					Log(string.Format(NinjaTrader.Custom.Resource.NinjaScriptOnBarCloseError, Name), LogLevel.Error);
				}*/
			}
			else if (State == State.DataLoaded) //WH added 09/06/2017
			{				
				
				arrowFont = new NinjaTrader.Gui.Tools.SimpleFont("Wingdings", arrowSize){ Bold = true };
				
			}
			else if(State == State.Configure)
			{
				BarDelta = new Series<double>(this);
				TrueMomo = new Series<double>(this);
				DeltaMomo = new Series<double>(this);
				UpMomo = new Series<double>(this);
				DownMomo = new Series<double>(this);
				DeltaClose = new Series<double>(this);
			}
		}
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (CurrentBar <= BarsRequiredToPlot)
			{
				return;
			}
			if(e.MarketDataType == MarketDataType.Last)
			{
				if(e.Price >= e.Ask)
				{
					buys += e.Volume ;//* (Close[0] - Low[0]) / (High[0] - Low[0]);			
					if(sells < buys && e.Volume > Block)
					{
						//Draw.TriangleUp(this, "buy" +counter++, true, 0, e.Price, Brushes.Lime); 
						pushing_ask += 1;
						askBlockAccum += e.Volume;
						//AskBlockOrder[0] = askBlockAccum;
						int size = 10;
						DrawOnPricePanel = true;
						if(e.Volume >= Block && e.Volume < 2*Block)
						{
							size = 30;
							Draw.Text(this,"@2xAsk."+e.Price, true, Convert.ToString(e.Volume), 0, e.Price, 0,Brushes.Lime, 
								new SimpleFont("Small Fonts", 10), TextAlignment.Center,	Brushes.Transparent,Brushes.Transparent, 0);	
					
						}
						else
						if(e.Volume > 2*Block)
						{
							PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\pushing_ask.wav");
							size = 50;
							//Draw.FibonacciCircle(this, e.Volume+"@Ask."+e.Price, true, 0, e.Price-2*ATR(14)[0] ,0, e.Price+2*ATR(14)[0]);						
							//Draw.Ellipse(this, e.Volume+"@Ask."+e.Price, true, 2, e.Price+0.5*ATR(7)[0], -2, e.Price-0.5*ATR(7)[0], Brushes.Green, Brushes.LimeGreen, 0);	
							
							Draw.Text(this,"@2xAsk."+e.Price, true, Convert.ToString(e.Volume), 0, e.Price, 0,Brushes.Lime, 
								new SimpleFont("Small Fonts", 14), TextAlignment.Center,	Brushes.Transparent,Brushes.Transparent, 0);				
						}
					}
				}
				else if (e.Price <= e.Bid)
				{
					sells += e.Volume ;//* (High[0] - Close[0]) / (High[0] - Low[0]);;
					if(sells > buys && e.Volume > Block)
					{
						//Draw.TriangleDown(this, "sell" +counter++, true, 0, e.Price, Brushes.Red); 
						pushing_bid += 1;
						bidBlockAccum += e.Volume;
						//BidBlockOrder[0] = bidBlockAccum;
						int size = 10;
						DrawOnPricePanel = true;
						if(e.Volume >= Block && e.Volume < 2*Block)
						{
							size = 30;
							Draw.Text(this,"@2xAsk."+e.Price, true, Convert.ToString(e.Volume), 0, e.Price, 0,Brushes.Magenta, 
								new SimpleFont("Small Fonts", 10), TextAlignment.Center,	Brushes.Transparent,Brushes.Transparent, 0);	
						}
						else
						if(e.Volume > 2*Block)
						{
							PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\pushing_bid.wav");
							size = 50;
							//Draw.FibonacciCircle(this, e.Volume+"@Bid."+e.Price, true, 0, e.Price-2*ATR(14)[0] ,0, e.Price+2*ATR(14)[0]);
							Draw.Text(this,"@2xBid."+e.Price, true, Convert.ToString(e.Volume), 0, e.Price, 0,Brushes.Magenta, 
								new SimpleFont("Small Fonts", 14), TextAlignment.Center,	Brushes.Transparent,Brushes.Transparent, 0);				
						}
					}
				}
				// check if bids accelerating at a rapid pace or if asks accelerating
				if(buys + sells > BSThreshold && buys / sells >= BSPercent)
				{
					Draw.Text(this, "BSP1.8+."+CurrentBar, false, "u", 1, e.Price, 0, Brushes.Lime, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);					
				}
				else
				if(buys + sells > BSThreshold && sells / buys >= BSPercent)
				{
					Draw.Text(this, "BSP1.8-."+CurrentBar, false, "u", 1, e.Price, 0, Brushes.Red, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);					
				}
				
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < activeBar || CurrentBar <= BarsRequiredToPlot)
			{
				return;
			}

			// New Bar has been formed
			// - Assign last volume counted to the prior bar
			// - Reset volume count for new bar
			if(Bars.IsFirstBarOfSession)
			{
				RollingMaxMomo = BSThreshold;
			}			
			DrawOnPricePanel = true;	
			
				
			if (CurrentBar != activeBar)
			{
				
				kcDelta = KeltnerChannel(TrueMomo, 2, 20);
				//if(BSThreshold == 0 ) 
					RollingMaxMomo = kcDelta.Upper[0];//BSThreshold ;//
				//else
				//	RollingMaxMomo = BSThreshold ;
				
				//DeltaNoPrintClose[0] = buys - sells;
				
				/*if(CrossAbove(Volume, KeltnerChannel(Volume, 2, 20).Upper, 2))
				{
					Draw.Text(this, "Vupper."+CurrentBar, false, "w", 1, High[1]*0.5+Low[1]*0.5, 0, Brushes.Black, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
				}*/
				
				if(TrueMomo[1] > 0 && TrueMomo[2] < 0 && (Math.Abs(TrueMomo[2]) + TrueMomo[1]) > RollingMaxMomo)//Math.Min(RollingMaxMomo[0], BSThreshold)
				//	&& TrueMomo[1] > RollingMaxMomo[0] * 0.5)
				{
					//Print(CurrentBar + " --- " + (Math.Abs(TrueMomo[0]) + TrueMomo[1]));
					//Draw.ArrowUp(this, "UP." +CurrentBar.ToString(), true, 0, 0 , Brushes.SeaGreen);
					Draw.Text(this, "TMUpSwitch."+CurrentBar, false, "é", 1, Low[1], 0, Brushes.Cyan, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
					PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\strong_buy.wav");
				}
				else
				if(TrueMomo[3] < 0 && TrueMomo[2] > 0 && TrueMomo[1] > RollingMaxMomo)
				{
					//Print(CurrentBar + " --- " + TrueMomo[0]);
					//Draw.ArrowUp(this, "UP.." +CurrentBar.ToString(), true, 0, 0 , Brushes.SeaGreen);
					Draw.Text(this, "TMUpContinuation.."+CurrentBar, false, "é", 1, Low[1], 0, Brushes.YellowGreen, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
					//PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\strong_buy.wav");
				}
				else
				if(TrueMomo[1] < 0 && TrueMomo[2] > 0 && (Math.Abs(TrueMomo[1]) + TrueMomo[2]) > RollingMaxMomo)
				{
					//Print(CurrentBar + " --- " + (Math.Abs(TrueMomo[0]) + TrueMomo[1]));
					//Draw.ArrowDown(this, "DN." +CurrentBar.ToString(), true, 0, 0, Brushes.Red);
					Draw.Text(this, "TMDownSwitch."+CurrentBar, false, "ê", 1, High[1] ,0, Brushes.Red, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
					PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\strong_sell.wav");
				} 
				else
				if(TrueMomo[3] > 0 && TrueMomo[2] < 0 && TrueMomo[1]  < -RollingMaxMomo)
				{
					//Print(CurrentBar + " --- " + TrueMomo[0]);
					//Draw.ArrowDown(this, "DN.." +CurrentBar.ToString(), true, 0, 0, Brushes.Red);
					Draw.Text(this, "TMDownContinuation.."+CurrentBar, false, "ê", 1, High[1] ,0, Brushes.IndianRed, arrowFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
					//PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\strong_sell.wav");
				}
				
				//DrawOnPricePanel = false;
				bidBlockAccum = 0;
				askBlockAccum = 0;
								
				
				// assign weight
				buys = 0;
				sells = 0;
								
				activeBar = CurrentBar;
				
				if (UpMomo[1] > DownMomo[1])
					DownMomo[0] = 0; // reset - delta 		
				else
					UpMomo[0] = 0;								
			}
			BarDelta[0] = buys - sells;
			

			// if u came in rolling + delta from before, then add this + to it, otherwise init with this + 
			if(Bars.IsFirstBarOfSession)
			{
				BarDelta[0] = 0;
				TrueMomo[0] = 0;	
				UpMomo[0] = 0;
				DownMomo[0] = 0;
			}
			else
			if (BarDelta[0] > 0)
			{
						
				// check if rolling + before
				if (DeltaMomo[1] > 0)
				{
					DeltaMomo[0] = DeltaMomo[1] + BarDelta[0];
					if(BarDelta[0] < BarDelta[1]) // delta decreased, TrueMomo showing some sellers
					{
						TrueMomo[0] = DeltaMomo[0] - (BarDelta[1] - BarDelta[0]);
					}
					else
					{
						TrueMomo[0] = DeltaMomo[0];	// delta decreated, no hidden buyers 
					}
				}
				else
				{// - to +
					DeltaMomo[0] = BarDelta[0];
					TrueMomo[0] = Math.Abs(BarDelta[1]) + BarDelta[0];
				}
				
				UpMomo[0] = DeltaMomo[0];
			}

			if (BarDelta[0] < 0)
			{
				
				if (DeltaMomo[1] < 0)
				{
					DeltaMomo[0] = DeltaMomo[1] + BarDelta[0];	
					if(BarDelta[0] > BarDelta[1]) // delta increased, TrueMomo showing some buyers
					{
						TrueMomo[0] = DeltaMomo[0] + BarDelta[0] - BarDelta[1];
					}
					else
					{
						TrueMomo[0] = DeltaMomo[0];	// delta decreated, no hidden buyers 
					}									
				}
				else
				{ // +  to -
					DeltaMomo[0] = BarDelta[0];
					TrueMomo[0] = -(Math.Abs(BarDelta[1]) +  Math.Abs(BarDelta[0]));
				}
				DownMomo[0] = DeltaMomo[0];
			}
			
		}

		#region Properties
		
		[Range(0, 2000), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Block", GroupName = "NinjaScriptStrategyParameters", Order = 0)]
		public int Block
		{ get; set; }
		[Range(0, 10000), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "BSThreshold", GroupName = "NinjaScriptStrategyParameters", Order = 0)]
		public int BSThreshold
		{ get; set; }
		[Range(1, 1000), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "BSPercent", GroupName = "NinjaScriptStrategyParameters", Order = 0)]
		public double BSPercent
		{ get; set; }
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private DeltaNoPrint[] cacheDeltaNoPrint;
		public DeltaNoPrint DeltaNoPrint(int block, int bSThreshold, double bSPercent)
		{
			return DeltaNoPrint(Input, block, bSThreshold, bSPercent);
		}

		public DeltaNoPrint DeltaNoPrint(ISeries<double> input, int block, int bSThreshold, double bSPercent)
		{
			if (cacheDeltaNoPrint != null)
				for (int idx = 0; idx < cacheDeltaNoPrint.Length; idx++)
					if (cacheDeltaNoPrint[idx] != null && cacheDeltaNoPrint[idx].Block == block && cacheDeltaNoPrint[idx].BSThreshold == bSThreshold && cacheDeltaNoPrint[idx].BSPercent == bSPercent && cacheDeltaNoPrint[idx].EqualsInput(input))
						return cacheDeltaNoPrint[idx];
			return CacheIndicator<DeltaNoPrint>(new DeltaNoPrint(){ Block = block, BSThreshold = bSThreshold, BSPercent = bSPercent }, input, ref cacheDeltaNoPrint);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.DeltaNoPrint DeltaNoPrint(int block, int bSThreshold, double bSPercent)
		{
			return indicator.DeltaNoPrint(Input, block, bSThreshold, bSPercent);
		}

		public Indicators.DeltaNoPrint DeltaNoPrint(ISeries<double> input , int block, int bSThreshold, double bSPercent)
		{
			return indicator.DeltaNoPrint(input, block, bSThreshold, bSPercent);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.DeltaNoPrint DeltaNoPrint(int block, int bSThreshold, double bSPercent)
		{
			return indicator.DeltaNoPrint(Input, block, bSThreshold, bSPercent);
		}

		public Indicators.DeltaNoPrint DeltaNoPrint(ISeries<double> input , int block, int bSThreshold, double bSPercent)
		{
			return indicator.DeltaNoPrint(input, block, bSThreshold, bSPercent);
		}
	}
}

#endregion
